(function ($) {

	$(document).ready(function () {
		$(".filter__button").click(function (e) {
			e.preventDefault();

			if ($(this).hasClass("active")) {
				$(this).removeClass("active");
			} else {
				$(this).parent().find(".filter__button").removeClass('active');
				$(this).addClass('active');
			};
		});

	});

	//BURGER NENU OPEN AND CLOSE AFTER CLICK
	$(".filter__burger").click(function () {
		if ($(this).hasClass("open")) {
			$(this).removeClass("open");
			$(".filter").removeClass("open");
		} else {
			$(this).addClass("open");
			$(".filter").addClass("open");
		};
	});
	//HIDING BURGER MENU AND SUBCATEGORIES AFTER CLICK
	$(".filter__button").click(function () {
		if ($(this).hasClass('filter__button_drop')) {
			$(this).addClass('open');
		} else {
			$(".filter").removeClass("open");
			$(".filter__burger").removeClass("open");
		};
	});

})(jQuery);